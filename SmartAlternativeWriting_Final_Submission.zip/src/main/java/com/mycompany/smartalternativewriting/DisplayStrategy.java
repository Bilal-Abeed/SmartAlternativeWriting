package com.mycompany.smartalternativewriting;

public interface DisplayStrategy {
    String display(String input, EncoderPrototype encoder);
}

